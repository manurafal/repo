# -*- coding: utf-8 -*-

from core import httptools, scrapertools
from platformcode import logger


def test_video_exists(page_url):
    logger.info("(page_url='%s')" % page_url)
    data = httptools.downloadpage(page_url).data
    # ~ logger.debug(data)
    if '<b>File Not Found</b>' in data or 'The file was deleted by' in data or data == '':
        return False, "[Vidtodo] El fichero no existe o ha sido borrado"
    return True, ""


def get_video_url(page_url, premium=False, user="", password="", video_password=""):
    logger.info("url=" + page_url)
    video_urls = []

    data = httptools.downloadpage(page_url).data
    # ~ logger.debug(data)
    
    matches = scrapertools.find_multiple_matches(data, 'file\s*:\s*"([^"]+)"\s*,\s*label\s*:\s*"([^"]+)"')
    if matches:
        for url, lbl in matches:
            if url.endswith('.srt'): continue
            video_urls.append([lbl, url])
    else:
        matches = scrapertools.find_multiple_matches(data, 'file\s*:\s*"([^"]+)"')
        for url in matches:
            if url.endswith('.srt'): continue
            video_urls.append(['[vidtodo]', url])

    return video_urls
